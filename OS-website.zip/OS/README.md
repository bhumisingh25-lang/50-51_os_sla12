# KernelLab: Process Scheduling OS Suite

Interactive CPU scheduling simulator by **Atharva Shinde (50)** and **Bhumi Singh (51)**.

Algorithms: FCFS, Round Robin, and Dynamic Time Quantum Round Robin (DTQ-RR, Qmin = 2, Qmax = 6).

Open `index.html` in a browser, or host it with GitHub Pages.
